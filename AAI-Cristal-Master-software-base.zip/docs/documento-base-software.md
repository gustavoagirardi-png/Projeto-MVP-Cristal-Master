# AAI — Documento-base de desenvolvimento do software

**Projeto:** Almoxarifado Assistido por IA (AAI) — Cristal Master  
**Versão:** 0.1.0  
**Estado:** fundação do projeto  
**Responsável pela auditoria:** Manus AI  
**Escopo deste documento:** software; a parte elétrica permanece fora do escopo de implementação atual.

## 1. Objetivo

O AAI é um sistema operacional móvel para o almoxarifado. Seu objetivo é aproximar o registro digital da movimentação física, orientar o operador sobre o pallet correto e reduzir furos de estoque, atrasos de baixa e quebra do FIFO.

O primeiro release deve provar um fluxo completo e explicável: o supervisor disponibiliza uma Ordem de Produção (OP), o sistema recomenda o lote FIFO ou FEFO, o operador recebe a tarefa no celular, identifica o pallet, confirma a retirada e o sistema atualiza saldo, histórico e divergências.

> O núcleo do produto é a combinação entre regra determinística de estoque, operação móvel, validação do pallet, transação de baixa e auditoria. A IA é uma camada de apoio e não substitui essas regras.

## 2. Limites do escopo atual

### 2.1 Incluído no MVP de software

O MVP incluirá cadastro de usuários, materiais, lotes, pallets e posições; criação e consulta de OPs; recomendação FIFO/FEFO; tarefas móveis; leitura de código real ou simulada; confirmação de retirada; bloqueio de divergências; auditoria; dashboard mínimo; OCR básico de etiqueta; dados simulados; testes automatizados e roteiro de demonstração.

A aplicação deve funcionar inicialmente com dados simulados e sem depender da integração com o ERP de terceiros. A implementação inicial usará uma PWA responsiva para acelerar a validação em celular.

### 2.2 Fora do escopo atual

Ficam adiados o aplicativo Android nativo, a integração produtiva com ERP externo, múltiplos almoxarifados, operação offline completa, previsão de demanda, inventário visual contínuo, detecção avançada de avarias, controle de empilhadeiras, compras, faturamento, financeiro e gestão de fornecedores.

A parte elétrica também está fora do escopo atual. O software deverá apenas oferecer contratos de integração futuros, sem comandar sensores, motores, CLPs, leitores industriais ou outros dispositivos neste ciclo.

## 3. Princípios de arquitetura

1. **API como fronteira:** o cliente móvel não acessa o banco diretamente.
2. **Regra determinística:** FIFO/FEFO deve ser explicável, testável e independente de IA.
3. **Transação:** baixa, reserva e atualização de saldo devem ocorrer de forma atômica.
4. **Auditoria append-only:** eventos não são apagados; estornos geram novos eventos.
5. **Idempotência:** uma mesma confirmação não pode baixar o estoque duas vezes.
6. **Falha segura:** código desconhecido, lote bloqueado, saldo insuficiente e divergência não liberam a movimentação normal.
7. **Mobile first:** o fluxo do operador deve ser concluído no dispositivo móvel, sem retorno obrigatório ao desktop.
8. **Extensibilidade:** contratos de eventos e comandos futuros não devem contaminar o núcleo do estoque.
9. **IA com revisão:** OCR e inspeção visual retornam evidência e confiança; baixa confiança exige confirmação humana.
10. **Simplicidade operacional:** cada entrega deve ser executável e demonstrável.

## 4. Stack definida

| Camada | MVP | Evolução planejada |
|---|---|---|
| Backend | Python, FastAPI, Pydantic | serviços separados quando houver necessidade real |
| Persistência | SQLite | PostgreSQL |
| ORM | SQLAlchemy ou SQLModel | SQLAlchemy com Alembic |
| Cliente | PWA responsiva | Flutter ou React Native para Android |
| Código | QR Code/código de barras com entrada manual controlada | SDK de coletor industrial |
| OCR | OpenCV + Tesseract ou PaddleOCR | serviço de visão dedicado |
| Imagens | armazenamento local controlado | MinIO/S3 |
| Testes | Pytest | testes de integração, carga e campo |
| Execução | Uvicorn e script local | Docker Compose e observabilidade |

A escolha tecnológica pode mudar somente quando houver uma decisão registrada com motivo, impacto, alternativa descartada e plano de migração.

## 5. Módulos do sistema

### 5.1 Identidade e perfis

O MVP terá autenticação simples e perfis mínimos de operador e supervisor. O operador poderá consultar tarefas e confirmar movimentações autorizadas. O supervisor poderá criar ou consultar OPs, visualizar divergências e aprovar exceções. A produção deverá evoluir para OAuth2/OIDC ou provedor corporativo.

### 5.2 Cadastros e estoque

As entidades centrais são `Usuario`, `Material`, `Lote`, `Pallet`, `Posicao`, `OrdemProducao`, `ItemOP`, `Movimentacao`, `Auditoria`, `Excecao` e `Inspecao`. A modelagem deve preservar relações claras entre material, lote, pallet e posição física.

O saldo disponível deve ser calculável e protegido contra valores negativos. Lotes podem estar disponíveis, bloqueados, em quarentena, consumidos ou reservados.

### 5.3 OP e tarefas

Uma OP possui número, produto ou material solicitado, quantidade, prioridade e status. A partir da OP, o sistema cria ou expõe uma tarefa operacional com material, quantidade, lote recomendado, pallet esperado, posição e estado da execução.

### 5.4 Motor FIFO/FEFO

Para FIFO, o sistema ordena lotes elegíveis pela data de entrada mais antiga. Para FEFO, ordena pela validade mais próxima. Em ambos os casos, ignora lotes bloqueados, consumidos ou com quantidade disponível insuficiente, respeita reservas e impede saldo negativo.

O lote recomendado não deve ser substituído silenciosamente. Se o operador tentar outro pallet, o sistema deve bloquear ou abrir um fluxo de exceção com justificativa e autorização.

### 5.5 Movimentações e auditoria

A confirmação deve validar usuário, OP, material, lote, pallet, posição, quantidade e estado do lote dentro de uma transação. O evento de auditoria registra quem, quando, o quê, onde, quanto e qual foi o resultado da validação.

Estornos nunca removem o evento original. Eles geram uma nova movimentação relacionada ao evento estornado. A API deve aceitar uma chave de idempotência por operação.

### 5.6 Leitura e visão computacional

O código de barras ou QR Code será a primeira forma de identificação. OCR será fallback para etiquetas sem código legível ou para conferência textual. O resultado do OCR deve conter texto bruto, campos extraídos, confiança e indicação de revisão manual.

Detecção de avarias e reconhecimento do galpão são fases futuras. Nenhum resultado de visão avançada poderá liberar sozinho uma operação de segurança ou qualidade.

### 5.7 Dashboard

O dashboard inicial mostrará OPs abertas, saldos por lote, últimas movimentações, divergências, tentativas bloqueadas e tarefas pendentes. Indicadores avançados, como aderência ao FIFO, taxa de leitura e eventos offline, serão adicionados conforme existirem dados confiáveis.

## 6. Contratos de API iniciais

Os nomes abaixo são a referência inicial; cada endpoint deve ter esquema de entrada, saída, erros e teste.

| Método | Rota | Finalidade |
|---|---|---|
| GET | `/health` | verificar disponibilidade |
| GET | `/api/v1/ordens` | listar OPs |
| POST | `/api/v1/ordens` | criar OP |
| GET | `/api/v1/ordens/{id}/recomendacao` | obter lote FIFO/FEFO |
| POST | `/api/v1/movimentacoes/confirmar` | validar e confirmar retirada |
| POST | `/api/v1/movimentacoes/{id}/estornar` | gerar estorno relacionado |
| GET | `/api/v1/auditoria` | consultar eventos |
| POST | `/api/v1/leituras` | registrar código ou resultado OCR |
| POST | `/api/v1/excecoes` | solicitar exceção |
| GET | `/api/v1/dashboard/resumo` | obter indicadores mínimos |

Erros de domínio devem ser identificáveis, por exemplo: `LOT_BLOCKED`, `LOT_NOT_FIFO`, `INSUFFICIENT_BALANCE`, `UNKNOWN_PALLET`, `DUPLICATE_OPERATION` e `EXCEPTION_REQUIRED`.

## 7. Preparação para a futura parte elétrica

A parte elétrica será desenvolvida somente depois de o software operacional ser validado. Para manter abertura técnica sem antecipar escopo, o backend deverá reservar uma camada de integração baseada em eventos e adaptadores.

No futuro, dispositivos poderão publicar eventos como `device.read`, `sensor.state_changed`, `scale.weight_captured` e `equipment.fault`. O software poderá emitir comandos como `device.request_read` ou `equipment.request_confirmation`, sempre com identificador único, origem, data, correlação com OP ou movimentação e estado de processamento.

Nenhum evento elétrico deve alterar saldo diretamente. A movimentação continuará passando pela mesma validação de negócio usada pelo operador. A futura integração deverá ser substituível por adaptadores REST, MQTT, OPC-UA, serial ou outro protocolo aprovado, sem acoplar o domínio a uma marca de equipamento.

## 8. Fluxos obrigatórios de aceitação

### Fluxo correto

O supervisor cria uma OP. O sistema recomenda o lote mais antigo elegível. O operador abre a tarefa no celular, lê o pallet correto e confirma a quantidade. O saldo diminui e o evento aparece no histórico e no dashboard.

### Tentativa de quebra do FIFO

O operador lê um pallet mais novo enquanto existe lote antigo elegível. O sistema bloqueia a retirada normal e informa o motivo. Se o processo permitir exceção, o operador registra justificativa e o supervisor autoriza. A exceção fica auditada.

### Falha de leitura

Um código desconhecido ou uma etiqueta ilegível não confirma a retirada. O sistema permite nova captura, entrada manual controlada ou revisão humana, sem produzir baixa silenciosa.

### Falha de saldo ou lote

Lote bloqueado, quantidade insuficiente e saldo negativo devem gerar erro de domínio testado. Nenhuma alteração parcial pode permanecer no banco.

## 9. Qualidade, segurança e operação

Cada funcionalidade deve nascer com teste unitário e teste de integração quando cruzar limites de módulo. O conjunto mínimo cobre FIFO, FEFO, bloqueio, saldo insuficiente, duplicidade, estorno, permissões, auditoria e leitura desconhecida.

O código deve usar variáveis de ambiente para configuração, nunca gravar segredos no repositório e manter um `.env.example`. A produção exigirá HTTPS, gestão de identidade corporativa, controle de acesso por perfil, retenção de imagens e logs protegidos.

O MVP terá um comando simples de inicialização, carga de dados demonstrativos, backup do banco e plano manual de contingência. O comportamento da câmera não pode ser a única dependência da apresentação.

## 10. Método de trabalho entre os agentes

**DeepSeek** produzirá a primeira implementação pequena, com arquivos alterados, testes e instruções de execução. Ele não deve alterar funcionalidades não relacionadas.

**Claude** revisará a implementação, unificará nomenclatura, corrigirá inconsistências, verificará qualidade de código e consolidará a documentação.

**Manus AI** fará a auditoria independente. A auditoria verificará aderência à demanda, riscos de regra de negócio, segurança, cobertura de testes, estado do projeto e próximos passos. Manus também manterá o registro de decisões e impedimentos.

Toda entrega seguirá o ciclo: definir comportamento, propor arquivos, implementar o menor incremento, testar, revisar, executar manualmente, registrar decisão e criar commit.

## 11. Estado inicial e próximos passos

**Estado atual:** repositório criado e vazio; a base de software ainda precisa ser publicada; nenhum módulo funcional foi aceito; a integração elétrica está apenas prevista como extensão.

**Próximo incremento:** consolidar a fundação FastAPI, configuração, endpoint de saúde e teste básico.

Depois disso, a sequência recomendada é: modelos e banco; carga simulada; motor FIFO/FEFO; movimentação transacional; API operacional; PWA do operador; leitura de código; auditoria; OCR; dashboard; teste integrado e pacote de demonstração.

Cada etapa será concluída somente quando houver código executável, teste correspondente e documentação do estado.

## 12. Critérios de conclusão do primeiro release

O primeiro release de validação estará concluído quando o operador puder concluir a retirada de uma OP pelo celular, o sistema bloquear uma tentativa de lote incorreto, o saldo e a auditoria forem atualizados, o supervisor visualizar o resultado e o fluxo puder ser reiniciado com dados limpos.

A parte elétrica não é critério de conclusão deste release. Ela será iniciada em uma fase posterior, a partir dos contratos de integração registrados neste documento.

## Referências

[1]: https://fastapi.tiangolo.com/ "FastAPI Documentation"
[2]: https://docs.sqlalchemy.org/ "SQLAlchemy Documentation"
[3]: https://docs.pytest.org/ "pytest Documentation"
[4]: https://docs.opencv.org/ "OpenCV Documentation"
