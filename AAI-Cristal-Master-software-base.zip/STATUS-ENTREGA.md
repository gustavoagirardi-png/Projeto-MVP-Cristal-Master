# Pacote de entrega — AAI Cristal Master

## Conteúdo

Este pacote contém a primeira base do software do AAI — Almoxarifado Assistido por IA:

- documento-base técnico exclusivo da programação;
- README de execução;
- API FastAPI mínima;
- endpoint `/health`;
- teste automatizado inicial;
- configuração de dependências;
- modelo de variáveis de ambiente;
- regras de exclusão do repositório;
- cópia dos três PDFs usados como referência do projeto.

## Validação

O teste inicial foi executado com sucesso:

```text
1 passed
```

## Estado do projeto

O projeto está na fundação do software. Ainda não foram implementados cadastros, banco de dados, OPs, FIFO/FEFO, movimentações, PWA, leitura de códigos, OCR ou dashboard.

A parte elétrica está explicitamente fora do escopo desta entrega. O documento-base registra apenas os pontos de extensão futuros por eventos e adaptadores.

## Publicação

O repositório GitHub permanece sem os arquivos porque a autorização de escrita disponível nesta sessão recusou o `push` com erro 403. O pacote ZIP é a entrega completa e independente da base atual.
