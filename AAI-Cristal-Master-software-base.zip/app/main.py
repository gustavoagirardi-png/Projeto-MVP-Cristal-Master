from fastapi import FastAPI

app = FastAPI(
    title="AAI — Almoxarifado Assistido por IA",
    version="0.1.0",
    description="API inicial do MVP de movimentação móvel de estoque.",
)


@app.get("/health", tags=["system"])
def health() -> dict[str, str]:
    """Retorna o estado mínimo da API para diagnóstico e monitoramento."""
    return {"status": "ok", "service": "aai-api"}
