from datetime import date
from typing import Optional, Union, List
from pydantic import BaseModel, Field


class MaterialCreate(BaseModel):
    codigo: str = Field(min_length=1, max_length=50)
    descricao: str = Field(min_length=1, max_length=200)
    unidade: str = Field(min_length=1, max_length=20)


class MaterialUpdate(BaseModel):
    descricao: Optional[str] = Field(default=None, min_length=1, max_length=200)
    unidade: Optional[str] = Field(default=None, min_length=1, max_length=20)
    ativo: Optional[bool] = None


class OperadorCreate(BaseModel):
    matricula: str = Field(min_length=1, max_length=50)
    nome: str = Field(min_length=1, max_length=120)


class OperadorUpdate(BaseModel):
    nome: Optional[str] = Field(default=None, min_length=1, max_length=120)
    ativo: Optional[bool] = None


class OperatorLookup(BaseModel):
    matricula: str = Field(min_length=1, max_length=50)


class PosicaoCreate(BaseModel):
    codigo: str = Field(min_length=1, max_length=50)
    descricao: Optional[str] = Field(default=None, max_length=200)


class LoteCreate(BaseModel):
    material_id: int
    codigo: str = Field(min_length=1, max_length=50)
    validade: Optional[date] = None


class PalletCreate(BaseModel):
    lote_id: int
    codigo: str = Field(min_length=1, max_length=50)
    posicao_id: Optional[int] = None


class PalletBloqueio(BaseModel):
    bloqueado: bool


class ItemOPCreate(BaseModel):
    material_id: int
    quantidade: float = Field(gt=0)


class OrdemProducaoCreate(BaseModel):
    codigo: str = Field(min_length=1, max_length=50)
    produto: str = Field(min_length=1, max_length=200)
    prioridade: int = Field(default=3, ge=1, le=5)
    prazo: Optional[date] = None
    itens: List[ItemOPCreate] = []


class GerarTarefasInput(BaseModel):
    operador_id: Optional[int] = None


class TarefaInicio(BaseModel):
    matricula: str = Field(min_length=1, max_length=50)


class TarefaConclusao(BaseModel):
    matricula: str = Field(min_length=1, max_length=50)
    quantidade_retirada: float = Field(gt=0)
    pallet_id: Optional[int] = None
    posicao_id: Optional[int] = None
    observacao: Optional[str] = Field(default=None, max_length=500)


class EntradaEstoque(BaseModel):
    material_id: int
    lote_id: Optional[int] = None
    pallet_id: Optional[int] = None
    posicao_id: Optional[int] = None
    quantidade: float = Field(gt=0)
    observacao: Optional[str] = Field(default=None, max_length=500)


class ExcecaoCreate(BaseModel):
    tarefa_id: Optional[int] = None
    matricula: Optional[str] = Field(default=None, max_length=50)
    operador_id: Optional[int] = None
    motivo: str = Field(min_length=1, max_length=100)
    observacao: Optional[str] = Field(default=None, max_length=500)


class ExcecaoResolucao(BaseModel):
    decisao: str = Field(min_length=1, max_length=500)


class DeviceEventCreate(BaseModel):
    evento_id: str = Field(min_length=1, max_length=100)
    dispositivo_id: str = Field(min_length=1, max_length=100)
    baia: Optional[str] = Field(default=None, max_length=50)
    uid_rfid: Optional[str] = Field(default=None, max_length=100)
    tipo_evento: str = Field(min_length=1, max_length=100)
    valor: Optional[Union[str, bool, int, float]] = None
