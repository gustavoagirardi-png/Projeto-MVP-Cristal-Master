async function api(url, opcoes = {}) {
    const resp = await fetch(url, {
        headers: { "Content-Type": "application/json" },
        ...opcoes,
    });
    let dados = null;
    try { dados = await resp.json(); } catch (_) {}
    if (!resp.ok) {
        const msg = (dados && (dados.erro || (dados.detalhes && dados.detalhes[0]?.msg))) || `Erro ${resp.status}`;
        throw new Error(msg);
    }
    return dados;
}

function texto(valor) { return valor === null || valor === undefined ? "—" : String(valor); }

/* ---------------------------- Dashboard ---------------------------- */
async function carregarDashboard() {
    const cards = document.querySelector("#dashboard-cards");
    if (!cards) return;
    try {
        const d = await api("/api/dashboard");
        cards.innerHTML = `
            <div class="card"><span>${d.materiais_cadastrados}</span><small>Materiais</small></div>
            <div class="card"><span>${d.operadores_ativos}</span><small>Operadores ativos</small></div>
            <div class="card"><span>${d.tarefas_pendentes}</span><small>Pendentes</small></div>
            <div class="card"><span>${d.tarefas_em_andamento}</span><small>Em andamento</small></div>
            <div class="card"><span>${d.tarefas_concluidas}</span><small>Concluídas</small></div>
            <div class="card"><span>${d.tarefas_bloqueadas}</span><small>Bloqueadas</small></div>
            <div class="card"><span>${d.excecoes_abertas}</span><small>Exceções abertas</small></div>`;
        const movs = document.querySelector("#dashboard-movs");
        movs.innerHTML = d.movimentacoes_recentes.length
            ? d.movimentacoes_recentes.map(m => `<li>#${m.id} ${m.tipo} — material ${m.material_id} — qtd ${m.quantidade} — ${m.criado_em}</li>`).join("")
            : "<li>Sem movimentações.</li>";
        document.querySelector("#dashboard-excecoes").textContent = `${d.excecoes_abertas} aberta(s)`;
        const alertas = document.querySelector("#dashboard-alertas");
        alertas.innerHTML = d.alertas_estoque.length
            ? d.alertas_estoque.map(a => `<li>${a.codigo}: saldo ${a.saldo}</li>`).join("")
            : "<li>Sem alertas.</li>";
        const ev = document.querySelector("#dashboard-eventos");
        ev.innerHTML = d.eventos_dispositivos.length
            ? d.eventos_dispositivos.map(e => `<li>${e.criado_em} — ${e.dispositivo_id} — ${e.tipo_evento}</li>`).join("")
            : "<li>Sem eventos.</li>";
    } catch (e) {
        cards.innerHTML = `<p class="message">Erro: ${e.message}</p>`;
    }
}

/* ---------------------------- Materiais ---------------------------- */
async function carregarMateriais() {
    const tabela = document.querySelector("#tabela-materiais");
    if (!tabela) return;
    try {
        const materiais = await api("/api/materiais");
        const filtro = (document.querySelector("#busca-material")?.value || "").toLowerCase();
        tabela.innerHTML = materiais
            .filter(m => !filtro || m.codigo.toLowerCase().includes(filtro) || m.descricao.toLowerCase().includes(filtro))
            .map(m => `<tr>
                <td>${m.codigo}</td><td>${m.descricao}</td><td>${m.unidade}</td>
                <td>${m.ativo ? "Sim" : "Não"}</td>
                <td>
                    <button class="button secondary" data-acao="${m.ativo ? "desativar" : "ativar"}" data-id="${m.id}">
                        ${m.ativo ? "Desativar" : "Ativar"}
                    </button>
                </td></tr>`).join("") || "<tr><td colspan='5'>Nenhum material.</td></tr>";
        tabela.querySelectorAll("button[data-acao]").forEach(b => {
            b.addEventListener("click", async () => {
                try {
                    await api(`/api/materiais/${b.dataset.id}/${b.dataset.acao}`, { method: "POST", body: "{}" });
                    carregarMateriais();
                } catch (e) { alert(e.message); }
            });
        });
    } catch (e) { tabela.innerHTML = `<tr><td colspan="5">Erro: ${e.message}</td></tr>`; }
}

const formMaterial = document.querySelector("#form-material");
if (formMaterial) {
    formMaterial.addEventListener("submit", async ev => {
        ev.preventDefault();
        const dados = Object.fromEntries(new FormData(formMaterial));
        const msg = document.querySelector("#msg-material");
        try {
            await api("/api/materiais", { method: "POST", body: JSON.stringify(dados) });
            msg.textContent = "Material cadastrado.";
            formMaterial.reset();
            carregarMateriais();
        } catch (e) { msg.textContent = e.message; }
    });
    document.querySelector("#refresh-materiais")?.addEventListener("click", carregarMateriais);
    document.querySelector("#busca-material")?.addEventListener("input", carregarMateriais);
    carregarMateriais();
}

/* ---------------------------- Operadores ---------------------------- */
async function carregarOperadores() {
    const tabela = document.querySelector("#tabela-operadores");
    if (!tabela) return;
    try {
        const ops = await api("/api/operadores");
        tabela.innerHTML = ops.map(o => `<tr>
            <td>${o.matricula}</td><td>${o.nome}</td><td>${o.ativo ? "Sim" : "Não"}</td>
            <td>
                <button class="button secondary" data-id="${o.id}" data-ativo="${o.ativo ? 0 : 1}">
                    ${o.ativo ? "Desativar" : "Ativar"}
                </button>
            </td>
            <td><a href="/api/tarefas?operador_id=${o.id}" target="_blank">Ver</a></td>
        </tr>`).join("") || "<tr><td colspan='5'>Nenhum operador.</td></tr>";
        tabela.querySelectorAll("button[data-id]").forEach(b => {
            b.addEventListener("click", async () => {
                try {
                    await api(`/api/operadores/${b.dataset.id}`, {
                        method: "PUT",
                        body: JSON.stringify({ ativo: b.dataset.ativo === "1" }),
                    });
                    carregarOperadores();
                } catch (e) { alert(e.message); }
            });
        });
    } catch (e) { tabela.innerHTML = `<tr><td colspan="5">Erro: ${e.message}</td></tr>`; }
}

const formOperador = document.querySelector("#form-operador");
if (formOperador) {
    formOperador.addEventListener("submit", async ev => {
        ev.preventDefault();
        const dados = Object.fromEntries(new FormData(formOperador));
        const msg = document.querySelector("#msg-operador");
        try {
            await api("/api/operadores", { method: "POST", body: JSON.stringify(dados) });
            msg.textContent = "Operador cadastrado.";
            formOperador.reset();
            carregarOperadores();
        } catch (e) { msg.textContent = e.message; }
    });
    carregarOperadores();
}

/* ---------------------------- Ordens ---------------------------- */
function adicionarLinhaItem() {
    const container = document.querySelector("#itens-op");
    if (!container) return;
    const linha = document.createElement("div");
    linha.className = "linha-item";
    linha.innerHTML = `
        <input type="number" placeholder="Material ID" class="item-material" required>
        <input type="number" step="0.01" placeholder="Quantidade" class="item-quantidade" required>`;
    container.appendChild(linha);
}

const formOrdem = document.querySelector("#form-ordem");
if (formOrdem) {
    adicionarLinhaItem();
    document.querySelector("#add-item").addEventListener("click", adicionarLinhaItem);
    formOrdem.addEventListener("submit", async ev => {
        ev.preventDefault();
        const base = Object.fromEntries(new FormData(formOrdem));
        const itens = [...document.querySelectorAll("#itens-op .linha-item")].map(l => ({
            material_id: Number(l.querySelector(".item-material").value),
            quantidade: Number(l.querySelector(".item-quantidade").value),
        }));
        const payload = {
            codigo: base.codigo,
            produto: base.produto,
            prioridade: Number(base.prioridade) || 3,
            prazo: base.prazo || null,
            itens,
        };
        const msg = document.querySelector("#msg-ordem");
        try {
            await api("/api/ordens", { method: "POST", body: JSON.stringify(payload) });
            msg.textContent = "OP criada.";
            formOrdem.reset();
            document.querySelector("#itens-op").innerHTML = "";
            adicionarLinhaItem();
            carregarOrdens();
        } catch (e) { msg.textContent = e.message; }
    });
    carregarOrdens();
}

async function carregarOrdens() {
    const tabela = document.querySelector("#tabela-ordens");
    if (!tabela) return;
    try {
        const ordens = await api("/api/ordens");
        tabela.innerHTML = ordens.map(o => `<tr>
            <td>${o.id}</td><td>${o.codigo}</td><td>${o.produto}</td>
            <td>${o.prioridade}</td><td>${o.status}</td>
            <td>
                <a class="button secondary" href="/lider/ordens/${o.id}">Abrir</a>
                <button class="button" data-gerar="${o.id}">Gerar tarefas</button>
            </td></tr>`).join("") || "<tr><td colspan='6'>Nenhuma OP.</td></tr>";
        tabela.querySelectorAll("button[data-gerar]").forEach(b => {
            b.addEventListener("click", async () => {
                try {
                    await api(`/api/ordens/${b.dataset.gerar}/gerar-tarefas`, { method: "POST", body: "{}" });
                    alert("Tarefas geradas.");
                } catch (e) { alert(e.message); }
            });
        });
    } catch (e) { tabela.innerHTML = `<tr><td colspan="6">Erro: ${e.message}</td></tr>`; }
}

/* ---------------------------- OP Detalhes ---------------------------- */
const btnGerar = document.querySelector("#btn-gerar-tarefas");
if (btnGerar) {
    btnGerar.addEventListener("click", async () => {
        try {
            await api(`/api/ordens/${btnGerar.dataset.op}/gerar-tarefas`, { method: "POST", body: "{}" });
            document.querySelector("#msg-op").textContent = "Tarefas geradas.";
        } catch (e) { document.querySelector("#msg-op").textContent = e.message; }
    });
    document.querySelector("#btn-finalizar-op").addEventListener("click", async () => {
        try {
            await api(`/api/ordens/${btnGerar.dataset.op}/finalizar`, { method: "POST", body: "{}" });
            document.querySelector("#msg-op").textContent = "OP finalizada.";
        } catch (e) { document.querySelector("#msg-op").textContent = e.message; }
    });
    document.querySelector("#btn-cancelar-op").addEventListener("click", async () => {
        try {
            await api(`/api/ordens/${btnGerar.dataset.op}/cancelar`, { method: "POST", body: "{}" });
            document.querySelector("#msg-op").textContent = "OP cancelada.";
        } catch (e) { document.querySelector("#msg-op").textContent = e.message; }
    });
    (async () => {
        try {
            const tarefas = await api(`/api/tarefas?op_id=${btnGerar.dataset.op}`);
            document.querySelector("#lista-tarefas-op").innerHTML =
                tarefas.length ? tarefas.map(t =>
                    `<li>#${t.id} — ${t.material_codigo} — qtd ${t.quantidade} — ${t.status}</li>`
                ).join("") : "<li>Sem tarefas.</li>";
        } catch (e) {}
    })();
}

/* ---------------------------- Tarefas ---------------------------- */
async function carregarTarefas() {
    const tabela = document.querySelector("#tabela-tarefas");
    if (!tabela) return;
    const status = document.querySelector("#filtro-status")?.value || "";
    const url = status ? `/api/tarefas?status=${status}` : "/api/tarefas";
    try {
        const tarefas = await api(url);
        tabela.innerHTML = tarefas.map(t => `<tr>
            <td>${t.id}</td><td>${texto(t.op_codigo)}</td>
            <td>${texto(t.material_codigo)}</td><td>${t.quantidade}</td>
            <td>${texto(t.operador_nome)}</td><td>${t.status}</td><td>${t.prioridade}</td>
        </tr>`).join("") || "<tr><td colspan='7'>Sem tarefas.</td></tr>";
    } catch (e) { tabela.innerHTML = `<tr><td colspan="7">Erro: ${e.message}</td></tr>`; }
}
if (document.querySelector("#tabela-tarefas")) {
    document.querySelector("#refresh-tarefas").addEventListener("click", carregarTarefas);
    carregarTarefas();
}

/* ---------------------------- Movimentações ---------------------------- */
async function carregarMovimentacoes() {
    const tabela = document.querySelector("#tabela-movimentacoes");
    if (!tabela) return;
    try {
        const movs = await api("/api/movimentacoes");
        tabela.innerHTML = movs.map(m => `<tr>
            <td>${m.id}</td><td>${m.tipo}</td><td>${m.material_codigo}</td>
            <td>${m.quantidade}</td><td>${texto(m.operador_nome)}</td>
            <td>${texto(m.op_codigo)}</td><td>${m.criado_em}</td>
        </tr>`).join("") || "<tr><td colspan='7'>Sem movimentações.</td></tr>";
    } catch (e) { tabela.innerHTML = `<tr><td colspan="7">Erro: ${e.message}</td></tr>`; }
}
if (document.querySelector("#tabela-movimentacoes")) carregarMovimentacoes();

/* ---------------------------- Auditoria ---------------------------- */
async function carregarAuditoria() {
    const tabela = document.querySelector("#tabela-auditoria");
    if (!tabela) return;
    try {
        const registros = await api("/api/auditoria");
        tabela.innerHTML = registros.map(a => `<tr>
            <td>${a.id}</td><td>${a.entidade}</td><td>${texto(a.entidade_id)}</td>
            <td>${a.acao}</td><td>${a.criado_em}</td>
        </tr>`).join("") || "<tr><td colspan='5'>Sem registros.</td></tr>";
    } catch (e) { tabela.innerHTML = `<tr><td colspan="5">Erro: ${e.message}</td></tr>`; }
}
if (document.querySelector("#tabela-auditoria")) {
    document.querySelector("#refresh-auditoria").addEventListener("click", carregarAuditoria);
    carregarAuditoria();
}

/* ---------------------------- Dispositivos ---------------------------- */
async function carregarDispositivos() {
    const lista = document.querySelector("#lista-dispositivos");
    const tabela = document.querySelector("#tabela-eventos");
    if (!lista || !tabela) return;
    try {
        const disps = await api("/api/dispositivos");
        lista.innerHTML = disps.length
            ? disps.map(d => `<li>${d.dispositivo_id} — ${d.total_eventos} evento(s) — último: ${texto(d.ultimo_contato)}</li>`).join("")
            : "<li>Nenhum dispositivo identificado.</li>";
        const eventos = await api("/api/dispositivos/eventos");
        tabela.innerHTML = eventos.map(e => `<tr>
            <td>${e.id}</td><td>${e.dispositivo_id}</td><td>${texto(e.baia)}</td>
            <td>${texto(e.uid_rfid)}</td><td>${e.tipo_evento}</td><td>${e.criado_em}</td>
        </tr>`).join("") || "<tr><td colspan='6'>Sem eventos.</td></tr>";
    } catch (e) { tabela.innerHTML = `<tr><td colspan="6">Erro: ${e.message}</td></tr>`; }
}
if (document.querySelector("#tabela-eventos")) {
    document.querySelector("#refresh-dispositivos").addEventListener("click", carregarDispositivos);
    carregarDispositivos();
}

/* ---------------------------- Exceções ---------------------------- */
async function carregarExcecoes() {
    const tabela = document.querySelector("#tabela-excecoes");
    if (!tabela) return;
    try {
        const excecoes = await api("/api/excecoes");
        tabela.innerHTML = excecoes.map(e => `<tr>
            <td>${e.id}</td><td>${texto(e.operador_nome)}</td>
            <td>${texto(e.op_codigo)}</td><td>${texto(e.tarefa_id)}</td>
            <td>${e.motivo}</td><td>${e.status}</td>
            <td>${e.status === "aberta"
                ? `<button class="button" data-resolver="${e.id}">Resolver</button>`
                : texto(e.decisao)}</td>
        </tr>`).join("") || "<tr><td colspan='7'>Sem exceções.</td></tr>";
        tabela.querySelectorAll("button[data-resolver]").forEach(b => {
            b.addEventListener("click", async () => {
                const decisao = prompt("Decisão:");
                if (!decisao) return;
                try {
                    await api(`/api/excecoes/${b.dataset.resolver}/resolver`, {
                        method: "POST", body: JSON.stringify({ decisao }),
                    });
                    carregarExcecoes();
                } catch (e) { alert(e.message); }
            });
        });
    } catch (e) { tabela.innerHTML = `<tr><td colspan="7">Erro: ${e.message}</td></tr>`; }
}
if (document.querySelector("#tabela-excecoes")) {
    document.querySelector("#refresh-excecoes").addEventListener("click", carregarExcecoes);
    carregarExcecoes();
}

/* ---------------------------- Estoque ---------------------------- */
const formEntrada = document.querySelector("#form-entrada");
if (formEntrada) {
    formEntrada.addEventListener("submit", async ev => {
        ev.preventDefault();
        const dados = Object.fromEntries(new FormData(formEntrada));
        for (const k of Object.keys(dados)) if (dados[k] === "") delete dados[k];
        dados.material_id = Number(dados.material_id);
        dados.quantidade = Number(dados.quantidade);
        if (dados.lote_id) dados.lote_id = Number(dados.lote_id);
        if (dados.pallet_id) dados.pallet_id = Number(dados.pallet_id);
        if (dados.posicao_id) dados.posicao_id = Number(dados.posicao_id);
        const msg = document.querySelector("#msg-entrada");
        try {
            await api("/api/movimentacoes/entrada", { method: "POST", body: JSON.stringify(dados) });
            msg.textContent = "Entrada registrada.";
            formEntrada.reset();
            carregarEstoque();
        } catch (e) { msg.textContent = e.message; }
    });
    carregarEstoque();
}

async function carregarEstoque() {
    const alvo = document.querySelector("#tab-saldo-material");
    if (!alvo) return;
    try {
        const d = await api("/api/estoque");
        alvo.innerHTML = d.por_material.map(m => `<tr><td>${m.codigo}</td><td>${m.descricao}</td><td>${m.unidade}</td><td>${m.saldo}</td></tr>`).join("");
        document.querySelector("#tab-saldo-lote").innerHTML =
            d.por_lote.map(l => `<tr><td>${l.codigo}</td><td>${l.material_codigo}</td><td>${texto(l.validade)}</td><td>${l.saldo}</td></tr>`).join("");
        document.querySelector("#tab-pallets").innerHTML = d.pallets.map(p => `<tr>
            <td>${p.id}</td><td>${p.codigo}</td><td>${p.lote_codigo}</td>
            <td>${texto(p.posicao_codigo)}</td><td>${p.bloqueado ? "Sim" : "Não"}</td>
            <td>${p.bloqueado
                ? `<button class="button secondary" data-pallet="${p.id}" data-bloq="0">Desbloquear</button>`
                : `<button class="button danger" data-pallet="${p.id}" data-bloq="1">Bloquear</button>`}</td>
        </tr>`).join("");
        document.querySelector("#tab-pallets").querySelectorAll("button[data-pallet]").forEach(b => {
            b.addEventListener("click", async () => {
                const acao = b.dataset.bloq === "1" ? "bloquear" : "desbloquear";
                try {
                    await api(`/api/pallets/${b.dataset.pallet}/${acao}`, { method: "POST", body: "{}" });
                    carregarEstoque();
                } catch (e) { alert(e.message); }
            });
        });
        document.querySelector("#lista-posicoes").innerHTML =
            d.posicoes.map(p => `<li>#${p.id} ${p.codigo} — ${texto(p.descricao)}</li>`).join("") || "<li>Sem posições.</li>";
        document.querySelector("#lista-bloqueados").innerHTML =
            d.itens_bloqueados.map(i => `<li>Pallet ${i.codigo} (${i.material_codigo}/${i.lote_codigo})</li>`).join("") || "<li>Sem itens bloqueados.</li>";
    } catch (e) {}
}
if (document.querySelector("#tab-saldo-material")) {
    document.querySelector("#refresh-estoque").addEventListener("click", carregarEstoque);
}

/* ---------------------------- Dashboard periódico ---------------------------- */
if (document.querySelector("#dashboard-cards")) {
    carregarDashboard();
    setInterval(carregarDashboard, 5000);
}
