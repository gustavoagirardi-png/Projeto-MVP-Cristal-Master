import json
import sqlite3
from datetime import datetime
from pathlib import Path

PASTA_DO_PROJETO = Path(__file__).resolve().parent
CAMINHO_DO_BANCO = PASTA_DO_PROJETO / "almoxarifado.db"


def conectar():
    conexao = sqlite3.connect(CAMINHO_DO_BANCO)
    conexao.row_factory = sqlite3.Row
    conexao.execute("PRAGMA foreign_keys = ON")
    return conexao


def agora():
    return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")


def inicializar_banco():
    conexao = conectar()
    conexao.executescript(
        """
        CREATE TABLE IF NOT EXISTS materiais (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo TEXT NOT NULL UNIQUE,
            descricao TEXT NOT NULL,
            unidade TEXT NOT NULL,
            ativo INTEGER NOT NULL DEFAULT 1,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS operadores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            matricula TEXT NOT NULL UNIQUE,
            nome TEXT NOT NULL,
            ativo INTEGER NOT NULL DEFAULT 1,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS posicoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo TEXT NOT NULL UNIQUE,
            descricao TEXT,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS lotes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            material_id INTEGER NOT NULL,
            codigo TEXT NOT NULL,
            validade TEXT,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(material_id, codigo),
            FOREIGN KEY(material_id) REFERENCES materiais(id)
        );
        CREATE TABLE IF NOT EXISTS pallets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lote_id INTEGER NOT NULL,
            codigo TEXT NOT NULL UNIQUE,
            posicao_id INTEGER,
            bloqueado INTEGER NOT NULL DEFAULT 0,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(lote_id) REFERENCES lotes(id),
            FOREIGN KEY(posicao_id) REFERENCES posicoes(id)
        );
        CREATE TABLE IF NOT EXISTS ordens_producao (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo TEXT NOT NULL UNIQUE,
            produto TEXT NOT NULL,
            prioridade INTEGER NOT NULL DEFAULT 3,
            prazo TEXT,
            status TEXT NOT NULL DEFAULT 'aberta',
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            finalizado_em TEXT
        );
        CREATE TABLE IF NOT EXISTS itens_ordem_producao (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            op_id INTEGER NOT NULL,
            material_id INTEGER NOT NULL,
            quantidade REAL NOT NULL,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(op_id) REFERENCES ordens_producao(id),
            FOREIGN KEY(material_id) REFERENCES materiais(id)
        );
        CREATE TABLE IF NOT EXISTS tarefas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            op_id INTEGER NOT NULL,
            item_id INTEGER NOT NULL,
            material_id INTEGER NOT NULL,
            operador_id INTEGER,
            quantidade REAL NOT NULL,
            prioridade INTEGER NOT NULL DEFAULT 3,
            status TEXT NOT NULL DEFAULT 'pendente',
            lote_recomendado_id INTEGER,
            pallet_id INTEGER,
            posicao_id INTEGER,
            quantidade_retirada REAL,
            observacao TEXT,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            iniciado_em TEXT,
            concluido_em TEXT,
            FOREIGN KEY(op_id) REFERENCES ordens_producao(id),
            FOREIGN KEY(item_id) REFERENCES itens_ordem_producao(id),
            FOREIGN KEY(material_id) REFERENCES materiais(id),
            FOREIGN KEY(operador_id) REFERENCES operadores(id)
        );
        CREATE TABLE IF NOT EXISTS movimentacoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tipo TEXT NOT NULL,
            material_id INTEGER NOT NULL,
            lote_id INTEGER,
            pallet_id INTEGER,
            posicao_origem_id INTEGER,
            posicao_destino_id INTEGER,
            quantidade REAL NOT NULL,
            operador_id INTEGER,
            tarefa_id INTEGER,
            op_id INTEGER,
            observacao TEXT,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(material_id) REFERENCES materiais(id)
        );
        CREATE TABLE IF NOT EXISTS auditoria (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            entidade TEXT NOT NULL,
            entidade_id INTEGER,
            acao TEXT NOT NULL,
            detalhes TEXT,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS eventos_dispositivo (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            evento_id TEXT NOT NULL UNIQUE,
            dispositivo_id TEXT NOT NULL,
            baia TEXT,
            uid_rfid TEXT,
            tipo_evento TEXT NOT NULL,
            valor TEXT,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS excecoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tarefa_id INTEGER,
            operador_id INTEGER,
            motivo TEXT NOT NULL,
            observacao TEXT,
            status TEXT NOT NULL DEFAULT 'aberta',
            decisao TEXT,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            resolvido_em TEXT,
            FOREIGN KEY(tarefa_id) REFERENCES tarefas(id),
            FOREIGN KEY(operador_id) REFERENCES operadores(id)
        );
        """
    )
    conexao.commit()
    conexao.close()


# ---------- Auditoria ----------

def registrar_auditoria(conexao, entidade, entidade_id, acao, detalhes=None):
    conexao.execute(
        "INSERT INTO auditoria (entidade, entidade_id, acao, detalhes) VALUES (?, ?, ?, ?)",
        (entidade, entidade_id, acao, json.dumps(detalhes or {}, ensure_ascii=False)),
    )


def listar_auditoria(limite=200):
    conexao = conectar()
    try:
        linhas = conexao.execute(
            "SELECT * FROM auditoria ORDER BY id DESC LIMIT ?", (limite,)
        ).fetchall()
        return [dict(l) for l in linhas]
    finally:
        conexao.close()


# ---------- Materiais ----------

def listar_materiais():
    conexao = conectar()
    try:
        linhas = conexao.execute(
            "SELECT * FROM materiais ORDER BY codigo"
        ).fetchall()
        return [dict(l) for l in linhas]
    finally:
        conexao.close()


def buscar_material(material_id):
    conexao = conectar()
    try:
        linha = conexao.execute(
            "SELECT * FROM materiais WHERE id = ?", (material_id,)
        ).fetchone()
        return dict(linha) if linha else None
    finally:
        conexao.close()


def criar_material(dados):
    conexao = conectar()
    try:
        cursor = conexao.execute(
            "INSERT INTO materiais (codigo, descricao, unidade) VALUES (?, ?, ?)",
            (dados["codigo"].strip(), dados["descricao"].strip(), dados["unidade"].strip()),
        )
        registrar_auditoria(conexao, "materiais", cursor.lastrowid, "criacao", dados)
        conexao.commit()
        return buscar_material(cursor.lastrowid)
    except sqlite3.IntegrityError as erro:
        raise ValueError("Código de material já cadastrado") from erro
    finally:
        conexao.close()


def atualizar_material(material_id, dados):
    conexao = conectar()
    try:
        campos = []
        valores = []
        for campo in ("descricao", "unidade"):
            if dados.get(campo) is not None:
                campos.append(f"{campo} = ?")
                valores.append(dados[campo].strip())
        if "ativo" in dados and dados["ativo"] is not None:
            campos.append("ativo = ?")
            valores.append(1 if dados["ativo"] else 0)
        if not campos:
            return buscar_material(material_id)
        valores.append(material_id)
        conexao.execute(
            f"UPDATE materiais SET {', '.join(campos)} WHERE id = ?", valores
        )
        registrar_auditoria(conexao, "materiais", material_id, "alteracao", dados)
        conexao.commit()
        return buscar_material(material_id)
    finally:
        conexao.close()


# ---------- Operadores ----------

def listar_operadores():
    conexao = conectar()
    try:
        linhas = conexao.execute(
            "SELECT * FROM operadores ORDER BY matricula"
        ).fetchall()
        return [dict(l) for l in linhas]
    finally:
        conexao.close()


def buscar_operador(matricula):
    conexao = conectar()
    try:
        linha = conexao.execute(
            "SELECT * FROM operadores WHERE matricula = ?", (matricula,)
        ).fetchone()
        return dict(linha) if linha else None
    finally:
        conexao.close()


def criar_operador(matricula, nome):
    conexao = conectar()
    try:
        cursor = conexao.execute(
            "INSERT INTO operadores (matricula, nome) VALUES (?, ?)",
            (matricula.strip(), nome.strip()),
        )
        registrar_auditoria(
            conexao, "operadores", cursor.lastrowid, "criacao",
            {"matricula": matricula, "nome": nome},
        )
        conexao.commit()
        linha = conexao.execute(
            "SELECT * FROM operadores WHERE id = ?", (cursor.lastrowid,)
        ).fetchone()
        return dict(linha)
    except sqlite3.IntegrityError as erro:
        raise ValueError("Matrícula já cadastrada") from erro
    finally:
        conexao.close()


def atualizar_operador(operador_id, dados):
    conexao = conectar()
    try:
        campos, valores = [], []
        if dados.get("nome") is not None:
            campos.append("nome = ?")
            valores.append(dados["nome"].strip())
        if "ativo" in dados and dados["ativo"] is not None:
            campos.append("ativo = ?")
            valores.append(1 if dados["ativo"] else 0)
        if campos:
            valores.append(operador_id)
            conexao.execute(
                f"UPDATE operadores SET {', '.join(campos)} WHERE id = ?", valores
            )
            registrar_auditoria(conexao, "operadores", operador_id, "alteracao", dados)
            conexao.commit()
        linha = conexao.execute(
            "SELECT * FROM operadores WHERE id = ?", (operador_id,)
        ).fetchone()
        return dict(linha) if linha else None
    finally:
        conexao.close()


# ---------- Posições / Lotes / Pallets ----------

def listar_posicoes():
    conexao = conectar()
    try:
        return [dict(l) for l in conexao.execute("SELECT * FROM posicoes ORDER BY codigo").fetchall()]
    finally:
        conexao.close()


def criar_posicao(codigo, descricao=None):
    conexao = conectar()
    try:
        cursor = conexao.execute(
            "INSERT INTO posicoes (codigo, descricao) VALUES (?, ?)",
            (codigo.strip(), (descricao or "").strip() or None),
        )
        registrar_auditoria(conexao, "posicoes", cursor.lastrowid, "criacao", {"codigo": codigo})
        conexao.commit()
        return dict(conexao.execute("SELECT * FROM posicoes WHERE id = ?", (cursor.lastrowid,)).fetchone())
    except sqlite3.IntegrityError as erro:
        raise ValueError("Posição já cadastrada") from erro
    finally:
        conexao.close()


def listar_lotes(material_id=None):
    conexao = conectar()
    try:
        if material_id:
            linhas = conexao.execute(
                "SELECT * FROM lotes WHERE material_id = ? ORDER BY criado_em, id",
                (material_id,),
            ).fetchall()
        else:
            linhas = conexao.execute("SELECT * FROM lotes ORDER BY id").fetchall()
        return [dict(l) for l in linhas]
    finally:
        conexao.close()


def criar_lote(material_id, codigo, validade=None):
    conexao = conectar()
    try:
        if not conexao.execute(
                "SELECT id FROM materiais WHERE id = ?", (material_id,)).fetchone():
            raise ValueError("Material inexistente")
        cursor = conexao.execute(
            "INSERT INTO lotes (material_id, codigo, validade) VALUES (?, ?, ?)",
            (material_id, codigo.strip(), validade),
        )
        registrar_auditoria(conexao, "lotes", cursor.lastrowid, "criacao",
                            {"material_id": material_id, "codigo": codigo})
        conexao.commit()
        return dict(conexao.execute("SELECT * FROM lotes WHERE id = ?", (cursor.lastrowid,)).fetchone())
    except sqlite3.IntegrityError as erro:
        raise ValueError("Lote já cadastrado para este material") from erro
    finally:
        conexao.close()


def listar_pallets():
    conexao = conectar()
    try:
        linhas = conexao.execute("""
            SELECT p.*, l.codigo AS lote_codigo, l.material_id AS material_id,
                   pos.codigo AS posicao_codigo
            FROM pallets p
            JOIN lotes l ON l.id = p.lote_id
            LEFT JOIN posicoes pos ON pos.id = p.posicao_id
            ORDER BY p.id
        """).fetchall()
        return [dict(l) for l in linhas]
    finally:
        conexao.close()


def criar_pallet(lote_id, codigo, posicao_id=None):
    conexao = conectar()
    try:
        if not conexao.execute(
                "SELECT id FROM lotes WHERE id = ?", (lote_id,)).fetchone():
            raise ValueError("Lote inexistente")
        if posicao_id is not None and not conexao.execute(
                "SELECT id FROM posicoes WHERE id = ?", (posicao_id,)).fetchone():
            raise ValueError("Posição inexistente")
        cursor = conexao.execute(
            "INSERT INTO pallets (lote_id, codigo, posicao_id) VALUES (?, ?, ?)",
            (lote_id, codigo.strip(), posicao_id),
        )
        registrar_auditoria(conexao, "pallets", cursor.lastrowid, "criacao",
                            {"lote_id": lote_id, "codigo": codigo})
        conexao.commit()
        return dict(conexao.execute("SELECT * FROM pallets WHERE id = ?", (cursor.lastrowid,)).fetchone())
    except sqlite3.IntegrityError as erro:
        raise ValueError("Pallet já cadastrado (código duplicado)") from erro
    finally:
        conexao.close()


def definir_bloqueio_pallet(pallet_id, bloqueado):
    """Retorna o pallet atualizado, ou None se o ID não existir."""
    conexao = conectar()
    try:
        if not conexao.execute(
                "SELECT id FROM pallets WHERE id = ?", (pallet_id,)).fetchone():
            return None
        conexao.execute(
            "UPDATE pallets SET bloqueado = ? WHERE id = ?",
            (1 if bloqueado else 0, pallet_id),
        )
        registrar_auditoria(conexao, "pallets", pallet_id,
                            "bloqueio" if bloqueado else "desbloqueio", {})
        conexao.commit()
        return dict(conexao.execute("SELECT * FROM pallets WHERE id = ?", (pallet_id,)).fetchone())
    finally:
        conexao.close()


# ---------- Estoque ----------

def calcular_saldo(material_id=None, lote_id=None, pallet_id=None):
    """Calcula saldo (entradas - saídas) filtrando por UMA referência por vez.
    Chamador deve escolher explicitamente qual granularidade quer consultar."""
    conexao = conectar()
    try:
        sql = (
            "SELECT COALESCE(SUM(CASE WHEN tipo='entrada' THEN quantidade ELSE 0 END)"
            " - SUM(CASE WHEN tipo='saida' THEN quantidade ELSE 0 END), 0) AS saldo"
            " FROM movimentacoes WHERE 1=1"
        )
        params = []
        if material_id is not None:
            sql += " AND material_id = ?"
            params.append(material_id)
        if lote_id is not None:
            sql += " AND lote_id = ?"
            params.append(lote_id)
        if pallet_id is not None:
            sql += " AND pallet_id = ?"
            params.append(pallet_id)
        linha = conexao.execute(sql, params).fetchone()
        return float(linha["saldo"])
    finally:
        conexao.close()


def estoque_por_material():
    conexao = conectar()
    try:
        linhas = conexao.execute("""
            SELECT m.id, m.codigo, m.descricao, m.unidade,
              COALESCE(SUM(CASE WHEN mv.tipo='entrada' THEN mv.quantidade ELSE 0 END)
                     - SUM(CASE WHEN mv.tipo='saida' THEN mv.quantidade ELSE 0 END), 0) AS saldo
            FROM materiais m
            LEFT JOIN movimentacoes mv ON mv.material_id = m.id
            GROUP BY m.id
            ORDER BY m.codigo
        """).fetchall()
        return [dict(l) for l in linhas]
    finally:
        conexao.close()


def estoque_por_lote():
    conexao = conectar()
    try:
        linhas = conexao.execute("""
            SELECT l.id, l.codigo, l.material_id, m.codigo AS material_codigo, l.validade,
              COALESCE(SUM(CASE WHEN mv.tipo='entrada' THEN mv.quantidade ELSE 0 END)
                     - SUM(CASE WHEN mv.tipo='saida' THEN mv.quantidade ELSE 0 END), 0) AS saldo
            FROM lotes l
            JOIN materiais m ON m.id = l.material_id
            LEFT JOIN movimentacoes mv ON mv.lote_id = l.id
            GROUP BY l.id
            ORDER BY l.id
        """).fetchall()
        return [dict(l) for l in linhas]
    finally:
        conexao.close()


def itens_bloqueados():
    conexao = conectar()
    try:
        linhas = conexao.execute("""
            SELECT p.id, p.codigo, p.bloqueado, l.codigo AS lote_codigo,
                   m.codigo AS material_codigo
            FROM pallets p
            JOIN lotes l ON l.id = p.lote_id
            JOIN materiais m ON m.id = l.material_id
            WHERE p.bloqueado = 1
        """).fetchall()
        return [dict(l) for l in linhas]
    finally:
        conexao.close()


# ---------- Ordens de Produção ----------

def listar_ordens():
    conexao = conectar()
    try:
        return [dict(l) for l in conexao.execute(
            "SELECT * FROM ordens_producao ORDER BY id DESC"
        ).fetchall()]
    finally:
        conexao.close()


def buscar_ordem(op_id):
    conexao = conectar()
    try:
        linha = conexao.execute("SELECT * FROM ordens_producao WHERE id = ?", (op_id,)).fetchone()
        if not linha:
            return None
        ordem = dict(linha)
        ordem["itens"] = [dict(l) for l in conexao.execute(
            "SELECT * FROM itens_ordem_producao WHERE op_id = ?", (op_id,)
        ).fetchall()]
        return ordem
    finally:
        conexao.close()


def criar_ordem(dados):
    conexao = conectar()
    try:
        for item in dados.get("itens", []):
            if not conexao.execute(
                    "SELECT id FROM materiais WHERE id = ?", (item["material_id"],)).fetchone():
                raise ValueError(f"Material {item['material_id']} inexistente")
        cursor = conexao.execute(
            "INSERT INTO ordens_producao (codigo, produto, prioridade, prazo) VALUES (?, ?, ?, ?)",
            (dados["codigo"].strip(), dados["produto"].strip(),
             int(dados.get("prioridade", 3)), dados.get("prazo")),
        )
        op_id = cursor.lastrowid
        for item in dados.get("itens", []):
            conexao.execute(
                "INSERT INTO itens_ordem_producao (op_id, material_id, quantidade) VALUES (?, ?, ?)",
                (op_id, item["material_id"], float(item["quantidade"])),
            )
        registrar_auditoria(conexao, "ordens_producao", op_id, "criacao", dados)
        conexao.commit()
        return buscar_ordem(op_id)
    except sqlite3.IntegrityError as erro:
        raise ValueError("Código de OP já cadastrado") from erro
    finally:
        conexao.close()


def atualizar_status_ordem(op_id, status):
    conexao = conectar()
    try:
        conexao.execute(
            "UPDATE ordens_producao SET status = ?, finalizado_em = ? WHERE id = ?",
            (status, agora() if status in ("finalizada", "cancelada") else None, op_id),
        )
        registrar_auditoria(conexao, "ordens_producao", op_id, status, {})
        conexao.commit()
        return buscar_ordem(op_id)
    finally:
        conexao.close()


def gerar_tarefas_da_ordem(op_id, operador_id=None):
    conexao = conectar()
    try:
        ordem = conexao.execute("SELECT * FROM ordens_producao WHERE id = ?", (op_id,)).fetchone()
        if not ordem:
            raise ValueError("OP não encontrada")
        if ordem["status"] in ("finalizada", "cancelada"):
            raise ValueError("OP não permite gerar tarefas neste estado")

        if operador_id is not None and not conexao.execute(
                "SELECT id FROM operadores WHERE id = ?", (operador_id,)).fetchone():
            raise ValueError("Operador inexistente")

        existentes = conexao.execute(
            "SELECT item_id FROM tarefas WHERE op_id = ?", (op_id,)
        ).fetchall()
        ja_gerados = {l["item_id"] for l in existentes}

        itens = conexao.execute(
            "SELECT * FROM itens_ordem_producao WHERE op_id = ?", (op_id,)
        ).fetchall()
        criadas = []
        for item in itens:
            if item["id"] in ja_gerados:
                continue
            lote_id = _recomendar_lote_fifo(conexao, item["material_id"], item["quantidade"])
            cursor = conexao.execute(
                """INSERT INTO tarefas
                   (op_id, item_id, material_id, operador_id, quantidade, prioridade, lote_recomendado_id)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (op_id, item["id"], item["material_id"], operador_id,
                 item["quantidade"], ordem["prioridade"], lote_id),
            )
            criadas.append(cursor.lastrowid)
            registrar_auditoria(conexao, "tarefas", cursor.lastrowid, "criacao",
                                {"op_id": op_id, "item_id": item["id"]})
        conexao.commit()
        return criadas
    finally:
        conexao.close()


def _recomendar_lote_fifo(conexao, material_id, quantidade):
    """Recomendação FIFO: lote mais antigo com saldo positivo."""
    linhas = conexao.execute("""
        SELECT l.id,
          COALESCE(SUM(CASE WHEN mv.tipo='entrada' THEN mv.quantidade ELSE 0 END)
                 - SUM(CASE WHEN mv.tipo='saida' THEN mv.quantidade ELSE 0 END), 0) AS saldo
        FROM lotes l
        LEFT JOIN movimentacoes mv ON mv.lote_id = l.id
        WHERE l.material_id = ?
        GROUP BY l.id
        ORDER BY l.criado_em ASC, l.id ASC
    """, (material_id,)).fetchall()
    for linha in linhas:
        if linha["saldo"] >= quantidade:
            return linha["id"]
    for linha in linhas:
        if linha["saldo"] > 0:
            return linha["id"]
    return None


# ---------- Tarefas ----------

def listar_tarefas(filtro=None):
    conexao = conectar()
    try:
        sql = """
        SELECT t.*, m.codigo AS material_codigo, m.descricao AS material_descricao,
               o.nome AS operador_nome, o.matricula AS operador_matricula,
               op.codigo AS op_codigo, l.codigo AS lote_codigo,
               p.codigo AS pallet_codigo, pos.codigo AS posicao_codigo
        FROM tarefas t
        JOIN materiais m ON m.id = t.material_id
        JOIN ordens_producao op ON op.id = t.op_id
        LEFT JOIN operadores o ON o.id = t.operador_id
        LEFT JOIN lotes l ON l.id = t.lote_recomendado_id
        LEFT JOIN pallets p ON p.id = t.pallet_id
        LEFT JOIN posicoes pos ON pos.id = t.posicao_id
        WHERE 1=1
        """
        params = []
        filtro = filtro or {}
        if filtro.get("op_id"):
            sql += " AND t.op_id = ?"
            params.append(filtro["op_id"])
        if filtro.get("operador_id"):
            sql += " AND t.operador_id = ?"
            params.append(filtro["operador_id"])
        if filtro.get("status"):
            sql += " AND t.status = ?"
            params.append(filtro["status"])
        sql += " ORDER BY t.id DESC"
        return [dict(l) for l in conexao.execute(sql, params).fetchall()]
    finally:
        conexao.close()


def buscar_tarefa(tarefa_id):
    conexao = conectar()
    try:
        linha = conexao.execute("""
        SELECT t.*, m.codigo AS material_codigo, m.descricao AS material_descricao, m.unidade AS material_unidade,
               o.nome AS operador_nome, o.matricula AS operador_matricula,
               op.codigo AS op_codigo, l.codigo AS lote_codigo,
               p.codigo AS pallet_codigo, pos.codigo AS posicao_codigo
        FROM tarefas t
        JOIN materiais m ON m.id = t.material_id
        JOIN ordens_producao op ON op.id = t.op_id
        LEFT JOIN operadores o ON o.id = t.operador_id
        LEFT JOIN lotes l ON l.id = t.lote_recomendado_id
        LEFT JOIN pallets p ON p.id = t.pallet_id
        LEFT JOIN posicoes pos ON pos.id = t.posicao_id
        WHERE t.id = ?
        """, (tarefa_id,)).fetchone()
        return dict(linha) if linha else None
    finally:
        conexao.close()


def iniciar_tarefa(tarefa_id, operador_id):
    conexao = conectar()
    try:
        t = conexao.execute("SELECT * FROM tarefas WHERE id = ?", (tarefa_id,)).fetchone()
        if not t:
            raise ValueError("Tarefa não encontrada")
        if t["status"] != "pendente":
            raise ValueError("Tarefa não está pendente")
        if t["operador_id"] is not None and t["operador_id"] != operador_id:
            raise ValueError("Tarefa atribuída a outro operador")
        conexao.execute(
            "UPDATE tarefas SET status = 'em_andamento', iniciado_em = ?, operador_id = ? WHERE id = ?",
            (agora(), operador_id, tarefa_id),
        )
        registrar_auditoria(conexao, "tarefas", tarefa_id, "inicio",
                            {"operador_id": operador_id})
        conexao.commit()
        return buscar_tarefa(tarefa_id)
    finally:
        conexao.close()


def concluir_tarefa(tarefa_id, quantidade_retirada, pallet_id=None,
                    posicao_id=None, observacao=None):
    conexao = conectar()
    try:
        t = conexao.execute("SELECT * FROM tarefas WHERE id = ?", (tarefa_id,)).fetchone()
        if not t:
            raise ValueError("Tarefa não encontrada")
        if t["status"] != "em_andamento":
            raise ValueError("Tarefa não está em andamento")

        material_id = t["material_id"]
        lote_id = None
        if pallet_id:
            linha_pallet = conexao.execute(
                "SELECT * FROM pallets WHERE id = ?", (pallet_id,)
            ).fetchone()
            if not linha_pallet:
                raise ValueError("Pallet informado não existe")
            if linha_pallet["bloqueado"]:
                raise ValueError("Pallet bloqueado não pode ser movimentado")
            lote_id = linha_pallet["lote_id"]
            lote_do_pallet = conexao.execute(
                "SELECT material_id FROM lotes WHERE id = ?", (lote_id,)).fetchone()
            if lote_do_pallet and lote_do_pallet["material_id"] != material_id:
                raise ValueError("Pallet pertence a material diferente da tarefa")
        elif t["lote_recomendado_id"]:
            lote_id = t["lote_recomendado_id"]

        # CORREÇÃO: seleciona explicitamente UMA granularidade de saldo,
        # nunca lote_id e pallet_id simultaneamente com fallback implícito.
        if pallet_id is not None:
            saldo = calcular_saldo(pallet_id=pallet_id)
        elif lote_id is not None:
            saldo = calcular_saldo(lote_id=lote_id)
        else:
            saldo = calcular_saldo(material_id=material_id)

        if saldo < float(quantidade_retirada):
            raise ValueError("Saldo insuficiente para conclusão")

        conexao.execute(
            """UPDATE tarefas SET status='concluida', concluido_em=?,
               quantidade_retirada=?, pallet_id=?, posicao_id=?, observacao=?
               WHERE id=?""",
            (agora(), float(quantidade_retirada), pallet_id, posicao_id,
             observacao, tarefa_id),
        )
        conexao.execute(
            """INSERT INTO movimentacoes
               (tipo, material_id, lote_id, pallet_id, posicao_destino_id, quantidade,
                operador_id, tarefa_id, op_id, observacao)
               VALUES ('saida', ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (material_id, lote_id, pallet_id, posicao_id, float(quantidade_retirada),
             t["operador_id"], tarefa_id, t["op_id"], observacao),
        )
        registrar_auditoria(conexao, "tarefas", tarefa_id, "conclusao",
                            {"quantidade_retirada": quantidade_retirada})
        conexao.commit()

        # Finalizar OP se todas as tarefas concluídas
        pendentes = conexao.execute(
            "SELECT COUNT(*) AS n FROM tarefas WHERE op_id = ? AND status NOT IN ('concluida','cancelada')",
            (t["op_id"],),
        ).fetchone()["n"]
        if pendentes == 0:
            conexao.execute(
                "UPDATE ordens_producao SET status='finalizada', finalizado_em=? WHERE id=?",
                (agora(), t["op_id"]),
            )
            conexao.commit()
        return buscar_tarefa(tarefa_id)
    finally:
        conexao.close()


# ---------- Movimentações ----------

def listar_movimentacoes(limite=500):
    conexao = conectar()
    try:
        linhas = conexao.execute("""
        SELECT mv.*, m.codigo AS material_codigo, o.nome AS operador_nome,
               op.codigo AS op_codigo
        FROM movimentacoes mv
        JOIN materiais m ON m.id = mv.material_id
        LEFT JOIN operadores o ON o.id = mv.operador_id
        LEFT JOIN ordens_producao op ON op.id = mv.op_id
        ORDER BY mv.id DESC LIMIT ?
        """, (limite,)).fetchall()
        return [dict(l) for l in linhas]
    finally:
        conexao.close()


def registrar_entrada(dados):
    conexao = conectar()
    try:
        material = conexao.execute("SELECT * FROM materiais WHERE id = ?",
                                   (dados["material_id"],)).fetchone()
        if not material:
            raise ValueError("Material inexistente")
        if not material["ativo"]:
            raise ValueError("Material inativo não pode receber entrada")

        lote_id = dados.get("lote_id")
        pallet_id = dados.get("pallet_id")
        posicao_id = dados.get("posicao_id")

        if lote_id:
            lote = conexao.execute(
                "SELECT * FROM lotes WHERE id = ?", (lote_id,)).fetchone()
            if not lote:
                raise ValueError("Lote inexistente")
            if lote["material_id"] != dados["material_id"]:
                raise ValueError("Lote não pertence ao material informado")

        if pallet_id:
            pallet = conexao.execute(
                "SELECT * FROM pallets WHERE id = ?", (pallet_id,)).fetchone()
            if not pallet:
                raise ValueError("Pallet inexistente")
            if lote_id and pallet["lote_id"] != lote_id:
                raise ValueError("Pallet não pertence ao lote informado")
            if not lote_id:
                lote_do_pallet = conexao.execute(
                    "SELECT material_id FROM lotes WHERE id = ?",
                    (pallet["lote_id"],)).fetchone()
                if lote_do_pallet and lote_do_pallet["material_id"] != dados["material_id"]:
                    raise ValueError("Pallet pertence a material diferente do informado")

        if posicao_id and not conexao.execute(
                "SELECT id FROM posicoes WHERE id = ?", (posicao_id,)).fetchone():
            raise ValueError("Posição inexistente")

        cursor = conexao.execute(
            """INSERT INTO movimentacoes
               (tipo, material_id, lote_id, pallet_id, posicao_destino_id,
                quantidade, operador_id, observacao)
               VALUES ('entrada', ?, ?, ?, ?, ?, ?, ?)""",
            (dados["material_id"], dados.get("lote_id"), dados.get("pallet_id"),
             dados.get("posicao_id"), float(dados["quantidade"]),
             dados.get("operador_id"), dados.get("observacao")),
        )
        registrar_auditoria(conexao, "movimentacoes", cursor.lastrowid,
                            "entrada", dados)
        conexao.commit()
        return dict(conexao.execute(
            "SELECT * FROM movimentacoes WHERE id = ?", (cursor.lastrowid,)
        ).fetchone())
    finally:
        conexao.close()


# ---------- Eventos de dispositivo ----------

def registrar_evento(dados):
    conexao = conectar()
    try:
        existe = conexao.execute(
            "SELECT id FROM eventos_dispositivo WHERE evento_id = ?",
            (dados["evento_id"],),
        ).fetchone()
        if existe:
            return ({"status": "duplicado", "evento_id": dados["evento_id"]}, False)

        cursor = conexao.execute(
            """INSERT INTO eventos_dispositivo
            (evento_id, dispositivo_id, baia, uid_rfid, tipo_evento, valor)
            VALUES (?, ?, ?, ?, ?, ?)""",
            (dados["evento_id"], dados["dispositivo_id"], dados.get("baia"),
             dados.get("uid_rfid"), dados["tipo_evento"],
             json.dumps(dados.get("valor"), ensure_ascii=False)),
        )
        registrar_auditoria(conexao, "eventos_dispositivo", cursor.lastrowid,
                            "recebido", dados)
        conexao.commit()
        return ({"status": "recebido", "id": cursor.lastrowid, **dados}, True)
    finally:
        conexao.close()


def listar_dispositivos():
    conexao = conectar()
    try:
        linhas = conexao.execute("""
        SELECT dispositivo_id,
               COUNT(*) AS total_eventos,
               MAX(criado_em) AS ultimo_contato
        FROM eventos_dispositivo
        GROUP BY dispositivo_id
        ORDER BY dispositivo_id
        """).fetchall()
        return [dict(l) for l in linhas]
    finally:
        conexao.close()


def listar_eventos_dispositivo(limite=200):
    conexao = conectar()
    try:
        linhas = conexao.execute(
            "SELECT * FROM eventos_dispositivo ORDER BY id DESC LIMIT ?", (limite,)
        ).fetchall()
        return [dict(l) for l in linhas]
    finally:
        conexao.close()


# ---------- Exceções ----------

def listar_excecoes():
    conexao = conectar()
    try:
        linhas = conexao.execute("""
        SELECT e.*, t.op_id AS tarefa_op_id, t.material_id AS tarefa_material_id,
               o.nome AS operador_nome, o.matricula AS operador_matricula,
               op.codigo AS op_codigo
        FROM excecoes e
        LEFT JOIN tarefas t ON t.id = e.tarefa_id
        LEFT JOIN operadores o ON o.id = e.operador_id
        LEFT JOIN ordens_producao op ON op.id = t.op_id
        ORDER BY e.id DESC
        """).fetchall()
        return [dict(l) for l in linhas]
    finally:
        conexao.close()


def criar_excecao(dados):
    conexao = conectar()
    try:
        if dados.get("tarefa_id") and not conexao.execute(
                "SELECT id FROM tarefas WHERE id = ?", (dados["tarefa_id"],)).fetchone():
            raise ValueError("Tarefa inexistente")
        cursor = conexao.execute(
            """INSERT INTO excecoes (tarefa_id, operador_id, motivo, observacao)
               VALUES (?, ?, ?, ?)""",
            (dados.get("tarefa_id"), dados.get("operador_id"),
             dados["motivo"], dados.get("observacao")),
        )
        if dados.get("tarefa_id"):
            conexao.execute(
                "UPDATE tarefas SET status = 'bloqueada' WHERE id = ?",
                (dados["tarefa_id"],),
            )
        registrar_auditoria(conexao, "excecoes", cursor.lastrowid, "abertura", dados)
        conexao.commit()
        return dict(conexao.execute(
            "SELECT * FROM excecoes WHERE id = ?", (cursor.lastrowid,)
        ).fetchone())
    finally:
        conexao.close()


def resolver_excecao(excecao_id, decisao):
    conexao = conectar()
    try:
        conexao.execute(
            "UPDATE excecoes SET status='resolvida', decisao=?, resolvido_em=? WHERE id=?",
            (decisao, agora(), excecao_id),
        )
        registro = conexao.execute(
            "SELECT * FROM excecoes WHERE id = ?", (excecao_id,)
        ).fetchone()
        if registro and registro["tarefa_id"]:
            conexao.execute(
                "UPDATE tarefas SET status='cancelada' WHERE id=? AND status='bloqueada'",
                (registro["tarefa_id"],),
            )
        registrar_auditoria(conexao, "excecoes", excecao_id, "resolucao",
                            {"decisao": decisao})
        conexao.commit()
        return dict(registro) if registro else None
    finally:
        conexao.close()


# ---------- Dashboard ----------

def resumo_dashboard():
    conexao = conectar()
    try:
        total_materiais = conexao.execute("SELECT COUNT(*) AS n FROM materiais").fetchone()["n"]
        operadores_ativos = conexao.execute(
            "SELECT COUNT(*) AS n FROM operadores WHERE ativo=1"
        ).fetchone()["n"]
        def contar_tarefas(status):
            return conexao.execute(
                "SELECT COUNT(*) AS n FROM tarefas WHERE status = ?", (status,)
            ).fetchone()["n"]
        pendentes = contar_tarefas("pendente")
        em_andamento = contar_tarefas("em_andamento")
        concluidas = contar_tarefas("concluida")
        bloqueadas = contar_tarefas("bloqueada")
        movimentacoes_recentes = [dict(l) for l in conexao.execute(
            "SELECT * FROM movimentacoes ORDER BY id DESC LIMIT 10"
        ).fetchall()]
        excecoes_abertas = conexao.execute(
            "SELECT COUNT(*) AS n FROM excecoes WHERE status='aberta'"
        ).fetchone()["n"]
        alertas_estoque = [dict(l) for l in conexao.execute("""
            SELECT m.codigo, COALESCE(SUM(CASE WHEN mv.tipo='entrada' THEN mv.quantidade ELSE 0 END)
                - SUM(CASE WHEN mv.tipo='saida' THEN mv.quantidade ELSE 0 END),0) AS saldo
            FROM materiais m LEFT JOIN movimentacoes mv ON mv.material_id = m.id
            GROUP BY m.id HAVING saldo <= 0
        """).fetchall()]
        eventos = [dict(l) for l in conexao.execute(
            "SELECT * FROM eventos_dispositivo ORDER BY id DESC LIMIT 10"
        ).fetchall()]
        return {
            "materiais_cadastrados": total_materiais,
            "operadores_ativos": operadores_ativos,
            "tarefas_pendentes": pendentes,
            "tarefas_em_andamento": em_andamento,
            "tarefas_concluidas": concluidas,
            "tarefas_bloqueadas": bloqueadas,
            "movimentacoes_recentes": movimentacoes_recentes,
            "excecoes_abertas": excecoes_abertas,
            "alertas_estoque": alertas_estoque,
            "eventos_dispositivos": eventos,
        }
    finally:
        conexao.close()
