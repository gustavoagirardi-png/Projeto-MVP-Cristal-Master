# AAI — Almoxarifado Assistido por IA

Base consolidada de apoio ao controle de almoxarifado e à retirada de
materiais para Ordens de Produção (OP). Duas áreas: **Líder** (administra) e
**Operador** (executa).

Este README reflete o estado real desta versão-base. Ele não afirma que o
sistema está pronto para produção nem que todas as regras operacionais
estão concluídas.

## Stack

Python, Flask, SQLite3, Pydantic, HTML, CSS, JavaScript. Sem Blueprints,
Application Factory, ORM, frameworks JS ou Docker.

## Estrutura de pastas

```
.
├── app.py
├── database.py
├── schemas.py
├── run.py
├── requirements.txt
├── README.md
├── .env.example
├── .gitignore
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── lider/        (dashboard, materiais, estoque, operadores, ordens,
│   │                   ordem-detalhes, tarefas, movimentacoes, auditoria,
│   │                   dispositivos, excecoes, _sidebar)
│   └── operador/      (acesso, inicio, tarefas, tarefa-detalhes,
│                        confirmacao, excecao)
├── static/
│   ├── css/style.css
│   ├── js/{lider.js, operador.js}
│   └── images/banner_smartcolector.jpg
└── scripts/
    └── smoke_test.py
```

## Instalação

```bash
python3 -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Execução

```bash
python run.py
# abrir http://127.0.0.1:5000
```

## Testes

```bash
python scripts/smoke_test.py
```

## Regra de permissão

```
Líder administra.
Operador executa.
```

A OP pertence à área do líder. O operador recebe e executa tarefas geradas
a partir da OP; não cria nem administra OP, material ou operador.

## Rotas HTML

```
GET  /
GET  /lider
GET  /lider/materiais
GET  /lider/estoque
GET  /lider/operadores
GET  /lider/ordens
GET  /lider/ordens/<id>
GET  /lider/tarefas
GET  /lider/movimentacoes
GET  /lider/auditoria
GET  /lider/dispositivos
GET  /lider/excecoes
GET  /operador
GET  /operador/inicio
GET  /operador/tarefas
GET  /operador/tarefas/<id>
GET  /operador/confirmacao
GET  /operador/excecao
```

## Rotas API

```
GET  /api/health
GET  /api/materiais                    POST /api/materiais
PUT  /api/materiais/<id>
POST /api/materiais/<id>/ativar        POST /api/materiais/<id>/desativar
GET  /api/operadores                   POST /api/operadores
PUT  /api/operadores/<id>
POST /api/operador/identificar
GET  /api/operador/tarefas?matricula=
POST /api/operador/tarefas/<id>/iniciar
POST /api/operador/tarefas/<id>/concluir
GET  /api/posicoes                     POST /api/posicoes
GET  /api/lotes                        POST /api/lotes
GET  /api/pallets                      POST /api/pallets
POST /api/pallets/<id>/bloquear        POST /api/pallets/<id>/desbloquear
GET  /api/estoque
POST /api/movimentacoes/entrada
GET  /api/movimentacoes
GET  /api/ordens                       POST /api/ordens
GET  /api/ordens/<id>
POST /api/ordens/<id>/gerar-tarefas
POST /api/ordens/<id>/finalizar        POST /api/ordens/<id>/cancelar
GET  /api/tarefas                      GET /api/tarefas/<id>
POST /api/tarefas/<id>/cancelar
GET  /api/excecoes                     POST /api/excecoes
POST /api/excecoes/<id>/resolver
GET  /api/dispositivos                 GET /api/dispositivos/eventos
POST /api/dispositivos/eventos
GET  /api/auditoria
GET  /api/dashboard
```

## Códigos HTTP

- 200 — OK
- 201 — criado
- 404 — registro inexistente (material, lote, pallet, posição, operador,
  tarefa, exceção, OP)
- 409 — conflito (duplicidade de código, referência incoerente, pallet
  bloqueado, saldo insuficiente, OP já encerrada, tarefa de outro operador)
- 422 — dados inválidos (validação Pydantic)
- 500 — erro inesperado não previsto (nunca expõe traceback; última
  barreira via `errorhandler(Exception)`)

## Tabelas

`materiais`, `operadores`, `posicoes`, `lotes`, `pallets`,
`ordens_producao`, `itens_ordem_producao`, `tarefas`, `movimentacoes`,
`auditoria`, `eventos_dispositivo`, `excecoes`. Nenhuma tabela nova foi
criada nesta etapa.

## Existe e funciona

- Cadastro/listagem/ativação/desativação de materiais, com validação de
  duplicidade e de existência (404 para ID inexistente).
- Cadastro/listagem/atualização de operadores; identificação por matrícula
  (sem senha).
- Posições, lotes e pallets, com validação de referência: lote exige
  material existente; pallet exige lote (e posição, se informada)
  existentes; mensagens de erro coerentes com a causa real.
- Bloqueio/desbloqueio de pallet, incluindo tratamento de ID inexistente
  (404, sem erro 500).
- Entrada de estoque com validação completa de referências e coerência:
  material, lote, pallet e posição precisam existir; lote precisa
  pertencer ao material informado; pallet precisa pertencer ao lote (ou
  ao material, quando só o pallet é informado).
- Ordens de Produção com itens, prioridade e prazo; validação de material
  inexistente antes da criação.
- Geração de tarefas a partir da OP, com recomendação FIFO de lote (regra
  já existente, não foi criada política nova) e validação de operador
  inexistente.
- Execução de tarefa pelo operador:
  - uma tarefa pré-atribuída a um operador não pode ser iniciada por outro;
  - bloqueio de pallet impede movimentação;
  - conclusão rejeita pallet de material diferente do da tarefa;
  - validação de saldo suficiente **antes** de gravar a saída, sempre
    numa única granularidade (pallet > lote > material), nunca combinando
    identificadores de forma ambígua.
- Finalização automática da OP quando todas as tarefas são concluídas.
- Abertura de exceção pelo operador (com validação de tarefa inexistente)
  e resolução pelo líder.
- Recebimento idempotente de evento de dispositivo (ESP/RFID) — duplicidade
  tratada.
- Auditoria de ações (criação, alteração, bloqueio, conclusão etc.).
- Dashboard do líder com dados reais do banco, atualizado por polling
  JavaScript a cada 5s (sem WebSocket).
- Todas as telas do líder e do operador abrem, carregam CSS/JS e não
  apresentam `TemplateNotFound`, seletor JS órfão ou link quebrado.
- Tratamento de erros em três camadas: 404 específico, `HTTPException`
  genérica e `Exception` genérica — nenhuma rota expõe traceback.

## Existe parcialmente

- **FIFO**: recomendação do lote mais antigo com saldo, usada na geração
  de tarefas. Não há divisão automática entre múltiplos lotes — se um
  único lote não cobre a quantidade, o sistema recomenda o primeiro com
  saldo positivo e deixa a conclusão validar o saldo disponível.
- **Integração ESP/RFID**: apenas recepção de evento JSON com idempotência
  básica (classificada como PREPARAÇÃO EXISTENTE). Nenhum firmware, GPIO
  ou protocolo elétrico é implementado; o formato final do evento depende
  da especificação da parte elétrica, ainda não entregue.

## Pendente

- Telas dedicadas de lote, pallet e posição no painel do líder (hoje
  geridos via API/telas de estoque existentes; não fazem parte desta
  entrega como telas próprias).
- FEFO — a tabela `lotes` guarda `validade`, mas não há regra que
  priorize lote por vencimento (decisão intencional: não foi criada
  política nova nesta etapa).

## Fora do escopo desta base

- Autenticação real (login/senha) do líder — o painel está aberto, sem
  sessão, cookies ou tokens. Ambiente de desenvolvimento apenas. A
  matrícula do operador continua sendo identificação provisória, não
  autenticação.
- Reserva de estoque, divisão de tarefa entre lotes, estorno, contagem
  física, replanejamento automático.
- Relatórios, exportações, impressão.
- WebSocket / notificações em tempo real.
- Integração com ERP externo.
- Câmera, OCR, visão computacional, leitura real de RFID/leitor físico.

## Limitações conhecidas

- Painel do líder aberto, sem autenticação — ambiente de desenvolvimento.
- O cálculo de saldo por pallet pressupõe que todas as entradas e saídas
  relevantes foram registradas com `pallet_id`. Sem isso, a granularidade
  cai para lote ou material.
- A recomendação FIFO não distribui uma tarefa entre múltiplos lotes.

## Exemplos

```bash
curl -X POST http://127.0.0.1:5000/api/materiais \
  -H 'Content-Type: application/json' \
  -d '{"codigo":"MAT-001","descricao":"Resina","unidade":"kg"}'

curl -X POST http://127.0.0.1:5000/api/dispositivos/eventos \
  -H 'Content-Type: application/json' \
  -d '{"evento_id":"EVT-001","dispositivo_id":"ESP32-A1","uid_rfid":"RFID-001","tipo_evento":"tag_detectada","valor":true}'
```
